#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    timerEnemy1 = new QTimer();
    connect(timerEnemy1, SIGNAL(timeout()), this,SLOT(moveEnemy1() ));

    timerEnemy2 = new QTimer();
    connect(timerEnemy2, SIGNAL(timeout()), this, SLOT(moveEnemy2() ));

    timerPlayer = new QTimer();
    connect(timerPlayer, SIGNAL(timeout()), this, SLOT(movePlayer() ));

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_btnNew_clicked()
{
timerEnemy1->start(100);
timerEnemy2->start(100);
ui->lbl_final->hide();
}

void MainWindow::on_control_sliderMoved(int position)
{
int y = position;
for(int i = 0; i<y; i++){

}

}

void MainWindow::moveEnemy1(){
int mode;
static int x = 0;
int y = ui->enemy1->geometry().y();

if(ui->btnDificil->isChecked()){
    mode = 2;
} else if (ui->btnFacil->isChecked()){
    mode = 1;
}


    static bool bandEnemy1 = true;

        if(ui->enemy1->geometry().x() < (ui->fondo->geometry().width() - ui->enemy1->geometry().width()) && bandEnemy1){

            ui->enemy1->setGeometry(x, y, ui->enemy1->width(), ui->enemy1->height());
                    x+=(10*mode);

            if(ui->enemy1->geometry().x() >= ( ui->fondo->geometry().width() - ui->enemy1->geometry().width()) ){
                    bandEnemy1 = false;
                }
        }

        if(!bandEnemy1){
            x-=(10*mode);
            ui->enemy1->setGeometry(x, y, ui->enemy1->width(), ui->enemy1->height());

            if(x == 0 || x<0){
                bandEnemy1 = true;
            }
        }
 }



void MainWindow::moveEnemy2(){

    static int x = 0;
    int mode;
    if(ui->btnDificil->isChecked()){
        mode = 2;
    } else if (ui->btnFacil->isChecked()){
        mode = 1;
    }

    int y = ui->enemy2->geometry().y();

    static bool bandEnemy2 = true;

        if(ui->enemy2->geometry().x() < (ui->fondo->geometry().width() - ui->enemy2->geometry().width()) && bandEnemy2){

            ui->enemy2->setGeometry(x, y, ui->enemy2->width(), ui->enemy2->height());
                    x+=(15*mode);

            if(ui->enemy2->geometry().x() >= ( ui->fondo->geometry().width() - ui->enemy2->geometry().width()) ){
                    bandEnemy2 = false;
                }
        }

        if(!bandEnemy2){
            x-=(15*mode);
            ui->enemy2->setGeometry(x, y, ui->enemy2->width(), ui->enemy2->height());

            if(x == 0 || x<0){
                bandEnemy2 = true;
            }
        }

}

void MainWindow::movePlayer(){
static int y = 0;
int x = ui->player->geometry().x();
static bool bandPlayer = true;
int punt = 0;




    if( ui->player->geometry().intersects(ui->enemy1->geometry()) || ui->player->geometry().intersects(ui->enemy2->geometry()) )
    {
        ui->player->setStyleSheet("background-image: url(:/img/img/player_dead.png)");
        timerEnemy1->stop();
        timerEnemy2->stop();
        timerPlayer->stop();
        ui->lbl_final->show();

    }

    if(ui->player->geometry().y() < ((this->height()-80) - ui->player->geometry().height()) && bandPlayer ){

        ui->player->setGeometry(x, y, ui->player->width(), ui->player->height());

        y+=10;

        punt = y;
        QString pntos; pntos.setNum(punt);
        ui->lbl_final->setText("Juego Terminado. Puntuación: "+pntos);

        ui->label_puntos->setText(QString::number(punt));
        if(ui->player->geometry().y() >= ((this->height()-80) - ui->player->geometry().height()) ){
            bandPlayer = false;
        }

    }

    if(!bandPlayer){

    y-=10;

    ui->player->setGeometry(x, y, ui->player->width(), ui->player->height());


    if(y == 0 || y<0){
        bandPlayer = true;
    }

    }

}

void MainWindow::on_btnStop_clicked()
{
timerEnemy1->stop();
timerEnemy2->stop();
}

void MainWindow::on_pushButton_2_clicked()
{
    timerPlayer->stop();
    ui->player->setStyleSheet("background-image: url(:/img/img/player_hidden.png)");
}

void MainWindow::on_pushButton_clicked()
{
    timerPlayer->start(100);
    timerEnemy1->start(100);
    timerEnemy2->start(100);

    ui->player->setStyleSheet("background-image: url(:/img/img/player.png)");
}

void MainWindow::on_pushButton_3_clicked()
{
    ui->enemy1->setGeometry(10, 110, ui->enemy1->geometry().width(), ui->enemy1->geometry().height());
    ui->enemy2->setGeometry(420, 170, ui->enemy1->geometry().width(), ui->enemy2->height());
    ui->player->setGeometry(300, 150, ui->player->width(), ui->player->height());
    ui->player->setStyleSheet("background-image: url(:/img/img/player_hidden.png)");}
