#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QTimer>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    //Botones de control de juego.
    void on_btnNew_clicked();
     void on_btnStop_clicked();

     //Botones de movimiento de personaje.
    void on_control_sliderMoved(int position);


    //Movimiento de los personajes.
    void moveEnemy1();

    void moveEnemy2();

    void movePlayer();


    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::MainWindow *ui;

    QTimer *timerEnemy1, *timerEnemy2, *timerPlayer;

};
#endif // MAINWINDOW_H
